'use strict';
const readline=require('node:readline/promises');
const { stdin:input, stdout:output }=require('node:process');
const { readDb, writeDb }=require('../lib/store');
const { makePassword, id }=require('../lib/security');
(async()=>{
 const rl=readline.createInterface({input,output});
 try{
  const username=(await rl.question('Admin username (3-20 karakter): ')).trim();
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(username))throw new Error('Username tidak valid.');
  const password=await rl.question('Admin password (minimal 12 karakter): ');
  if(password.length<12||password.length>72)throw new Error('Password admin harus 12-72 karakter.');
  const db=readDb();
  if(db.users.some(u=>u.username.toLowerCase()===username.toLowerCase()))throw new Error('Username sudah ada.');
  const creds=makePassword(password);
  db.users.push({id:id(),username,...creds,role:'admin',chips:0,createdAt:Date.now(),dailyClaimAt:0,refillAt:0,spins:0,wins:0});
  writeDb(db);console.log(`Admin ${username} berhasil dibuat. Buka https://DOMAIN-KAMU/admin untuk masuk.`);
 }catch(e){console.error(`Gagal: ${e.message}`);process.exitCode=1;}finally{rl.close();}
})();
