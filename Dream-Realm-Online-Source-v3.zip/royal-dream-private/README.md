# DREAM REALM — Online Community Game

Ini adalah proyek **game online mandiri** dengan tampilan fantasi ungu/emas, lobby, satu permainan slot 5×3 yang hasilnya dihitung di server, akun pemain, chip virtual gratis, leaderboard, dan panel admin.

> Proyek ini tidak terhubung ke server Royal Dream resmi, tidak menyalin kode/aset proprietary Royal Dream, dan bukan private server untuk membypass layanan resmi. Ini game original yang mengambil inspirasi umum dari gaya visual game fantasi. Semua chip hanya virtual: tidak ada deposit, cash-out, penarikan, atau hadiah bernilai uang.

## Fitur yang sudah ada

- Registrasi dan login dengan password di-hash memakai `scrypt`.
- Token sesi 30 hari.
- 100.000 chip virtual saat akun baru dibuat.
- Bonus harian 50.000 chip setiap 24 jam.
- Isi ulang gratis tanpa cooldown: +1.000.000.000 chip virtual setiap kali tombol ditekan, dapat diulang kapan saja.
- Nilai bet dapat diketik sendiri sebagai angka chip positif; MAX BET memakai seluruh saldo yang tersedia, bukan daftar nominal tetap.
- Game Gates of Olympus original: grid 5 kolom × 3 baris, nilai bet bebas, Max Bet seluruh saldo, Auto Spin, hasil dan perhitungan hadiah ditentukan server.
- Leaderboard pemain.
- Panel admin untuk memberi chip virtual dan mengatur pengumuman lobby.
- Tampilan responsif untuk Android dan bisa dipasang sebagai shortcut layar utama melalui browser yang mendukung PWA.
- Tidak memerlukan npm package pihak ketiga; memakai Node.js built-in modules.

## Menjalankan di komputer / server

Persyaratan: Node.js 20 atau lebih baru.

```bash
npm run check
npm start
```

Game akan tersedia di `http://localhost:8080`.

## Membuat akun admin

Hentikan server, lalu jalankan:

```bash
npm run admin:create
```

Masukkan username admin (3–20 karakter) dan password kuat (minimal 12 karakter). Jalankan server kembali, lalu buka `/admin` pada domain server.

## Membuatnya online untuk Android

1. Siapkan hosting yang mendukung aplikasi Node.js 20+.
2. Unggah seluruh isi folder proyek ini ke hosting atau repository privat.
3. Atur perintah start menjadi `npm start` dan port mengikuti variabel `PORT` dari hosting.
4. **Wajib** pasang persistent disk/volume untuk database. Atur `DB_PATH` ke lokasi di persistent disk, misalnya `/var/lib/dream-realm/db.json`. Jangan menaruh database produksi di filesystem sementara.
5. Aktifkan HTTPS pada domain hosting. Jangan mengirim password/token melalui HTTP publik.
6. Deploy, jalankan `npm run admin:create` di terminal hosting (atau jalankan secara lokal setelah mengatur `DB_PATH` ke volume yang sama), lalu login melalui `https://domain-kamu/admin`.
7. Buka domain game pada Chrome Android. Dari menu Chrome pilih **Tambahkan ke layar utama** untuk membuat ikon seperti aplikasi.

Catatan: file ini **belum di-hosting dan belum berupa APK**. Hosting, domain, persistent storage, dan HTTPS harus disediakan pemilik server. Jangan membagikan password admin atau token.

## Database & backup

Database JSON berada di `data/db.json` secara default. Sebelum setiap penulisan, server menyimpan salinan sebelumnya sebagai `data/db.json.bak`. Untuk deployment online, gunakan persistent disk dan buat backup terjadwal di sisi penyedia hosting. JSON store ini cocok untuk prototipe / komunitas kecil pada satu instance Node.js; untuk trafik besar atau multi-instance, migrasikan ke PostgreSQL dan gunakan transaksi database.

## API utama

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `POST /api/chips/daily`
- `POST /api/chips/refill`
- `POST /api/game/spin`
- `GET /api/leaderboard`
- `GET /api/admin/users` (admin)
- `POST /api/admin/grant` (admin)
- `POST /api/admin/notice` (admin)
- `GET /api/health`

## Batas prototipe

Saat ini hanya Gates of Olympus versi original yang aktif. Kartu game lain di lobby ditandai “segera hadir”; belum ada server multiplayer realtime, chat, payment, atau APK native. Hasil spin dihitung di server dan saldo diperiksa di server, bukan dipercayakan ke JavaScript browser.
