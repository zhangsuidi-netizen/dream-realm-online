'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));
const state = { token: localStorage.getItem('dreamrealm_token') || '', user: null, mode: 'login', view: 'home', bet: 100, spinning: false, auto: false, autoTimer: null, round: 1, toastTimer: null };
const MAX_CHIPS = Number.MAX_SAFE_INTEGER;
const symbolNames = { crown:'Mahkota', gem:'Permata', bolt:'Petir', orb:'Orb', clover:'Semanggi', moon:'Bulan', bell:'Lonceng' };
function fmt(n){return Number(n||0).toLocaleString('id-ID');}
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(state.toastTimer);state.toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
async function api(path, options={}){
  const headers={'Content-Type':'application/json',...(options.headers||{})};if(state.token)headers.Authorization=`Bearer ${state.token}`;
  const res=await fetch(path,{...options,headers,body:options.body===undefined?undefined:JSON.stringify(options.body)});
  let data={};try{data=await res.json();}catch{}
  if(!res.ok){if(res.status===401&&path!=='/api/auth/login'&&path!=='/api/auth/register'){logoutLocal();}throw new Error(data.error||`Server error ${res.status}`);}
  return data;
}
function setUser(user){state.user=user;$('#chipBalance').textContent=fmt(user.chips);$('#gameBalance').textContent=fmt(user.chips);$('#profileBalance').textContent=fmt(user.chips);if(state.bet>user.chips&&user.chips>0){state.bet=user.chips;updateBet();}$('#welcomeName').textContent=user.username;$('#profileName').textContent=user.username;$('#profileInitial').textContent=user.username.slice(0,1).toUpperCase();$('#accountButton').textContent=user.username.slice(0,1).toUpperCase();}
function showAuth(show=true){$('#authLayer').classList.toggle('show',show);}
function logoutLocal(){state.token='';state.user=null;localStorage.removeItem('dreamrealm_token');stopAuto();showAuth(true);}
async function refreshUser(){const d=await api('/api/me');setUser(d.user);$('#inboxNotice').textContent=d.notice||'Selamat datang di Dream Realm.';$('#claimHint').textContent=d.free.dailyReady?'Bonus harian siap diklaim':'Bonus harian: 50.000 chip / 24 jam';$('#dailyClaim').disabled=!d.free.dailyReady;$('#profileDaily').disabled=!d.free.dailyReady;$('#rewardDaily').disabled=!d.free.dailyReady;$('#gameRefill').disabled=!(d.free.refillReady);$('#profileRefill').disabled=!(d.free.refillReady);$('#rewardRefill').disabled=!(d.free.refillReady);return d;}
function setView(name){state.view=name;stopAuto();$$('.view').forEach(v=>v.classList.remove('active'));const target=$(`#${name}View`);if(target)target.classList.add('active');$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.nav===name));if(name==='rank')loadRank();if(name==='home')loadMiniRank();if(name==='game'){renderInitialReels();refreshUser().catch(()=>{});}window.scrollTo({top:0,behavior:'smooth'});}
function setAuthMode(mode){state.mode=mode;$$('[data-auth-mode]').forEach(b=>b.classList.toggle('selected',b.dataset.authMode===mode));$('#authSubmit').innerHTML=mode==='login'?'MASUK KE GAME <span>→</span>':'BUAT AKUN GRATIS <span>→</span>';$('#authPassword').autocomplete=mode==='login'?'current-password':'new-password';$('#authError').textContent='';}
function svgSymbol(kind){
 const common='xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"';
 const defs='<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff2b7"/><stop offset=".42" stop-color="#f6ca59"/><stop offset="1" stop-color="#ad5c20"/></linearGradient><linearGradient id="b" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#bdf7ff"/><stop offset=".5" stop-color="#4ba5e5"/><stop offset="1" stop-color="#2657a8"/></linearGradient><linearGradient id="p" x1="0" y1="0" x2=".8" y2="1"><stop stop-color="#fff0a5"/><stop offset=".55" stop-color="#e8a83d"/><stop offset="1" stop-color="#9c4d24"/></linearGradient></defs>';
 const shapes={
  crown:'<path d="M12 30L31 43 49 18 68 43 89 29 81 72H19Z" fill="url(#g)" stroke="#98521d" stroke-width="3"/><path d="M18 77H83" stroke="#fff1a7" stroke-width="6" stroke-linecap="round"/><circle cx="12" cy="27" r="6" fill="#ffed9b"/><circle cx="49" cy="14" r="7" fill="#fff0b3"/><circle cx="90" cy="26" r="6" fill="#f9dc83"/><circle cx="32" cy="49" r="5" fill="#42d5c1"/><circle cx="68" cy="49" r="5" fill="#3ab8df"/>',
  gem:'<path d="M18 35L34 16H68L84 35 51 86Z" fill="url(#b)" stroke="#e5f5ff" stroke-width="3"/><path d="M18 35H84L51 86Z" fill="#64b7ea"/><path d="M34 16L51 35 68 16M34 16L18 35M68 16L84 35M51 35V86" fill="none" stroke="#e6f8ff" stroke-width="3"/><path d="M18 35L51 86 36 35Z" fill="#dff9ff" opacity=".65"/>',
  bolt:'<path d="M58 7L22 55H45L37 94 80 42H56Z" fill="url(#g)" stroke="#a85b1a" stroke-width="3" stroke-linejoin="round"/><path d="M56 17L34 51H53L45 78 70 43H52Z" fill="#fff2a1" opacity=".55"/>',
  orb:'<circle cx="50" cy="51" r="34" fill="url(#p)" stroke="#ffe7a1" stroke-width="4"/><circle cx="50" cy="51" r="23" fill="#7a3bb0" stroke="#f7d77d" stroke-width="3"/><path d="M50 25L56 44 76 50 56 57 50 77 43 57 24 50 43 44Z" fill="#ffe7a2"/><circle cx="36" cy="35" r="6" fill="#fff" opacity=".65"/>',
  clover:'<g fill="#56bd74" stroke="#25834e" stroke-width="3"><path d="M48 48C14 50 17 14 35 17 44 18 48 31 50 39 55 14 81 12 82 31 83 43 70 49 59 50 87 53 84 80 66 82 54 84 49 68 49 58 47 84 20 86 18 68 17 57 31 49 48 48Z"/></g><path d="M50 51L61 89" stroke="#d2a64c" stroke-width="5" stroke-linecap="round"/>',
  moon:'<path d="M70 15C38 18 25 54 45 76 57 89 77 83 87 69 67 76 44 58 47 38 49 28 58 19 70 15Z" fill="url(#g)" stroke="#b16b22" stroke-width="3"/><path d="M68 17C48 25 39 51 51 68" fill="none" stroke="#fff2ac" stroke-width="4" stroke-linecap="round"/><circle cx="23" cy="27" r="4" fill="#f6d57c"/><circle cx="24" cy="68" r="3" fill="#f6d57c"/>',
  bell:'<path d="M24 67C32 58 28 30 42 22 54 15 69 23 72 39 75 54 73 59 83 68Z" fill="url(#g)" stroke="#95551d" stroke-width="3"/><path d="M19 69H85" stroke="#8b501b" stroke-width="5" stroke-linecap="round"/><path d="M39 78C42 91 62 91 66 78" fill="#edb94c" stroke="#9d5b22" stroke-width="3"/><path d="M48 27C42 38 46 48 45 54" stroke="#fff1ad" stroke-width="4" stroke-linecap="round"/><circle cx="52" cy="83" r="4" fill="#fff0a5"/>'
 };
 return `<svg ${common} role="img" aria-label="${symbolNames[kind]||kind}">${defs}${shapes[kind]||shapes.bolt}</svg>`;
}
function renderGrid(grid, winningRows=[]){const root=$('#reels');root.innerHTML='';for(let r=0;r<3;r++){for(let c=0;c<5;c++){const cell=document.createElement('div');cell.className='reel-cell';if(winningRows.includes(r))cell.classList.add('winner');cell.dataset.row=r;cell.dataset.col=c;cell.innerHTML=svgSymbol(grid?.[r]?.[c]||'bolt');root.append(cell);}}}
function randomPreview(){const kinds=Object.keys(symbolNames);return Array.from({length:3},()=>Array.from({length:5},()=>kinds[Math.floor(Math.random()*kinds.length)]));}
function renderInitialReels(){renderGrid(randomPreview());$('#roundLabel').textContent=`ROUND ${String(state.round).padStart(5,'0')}`;}
function setGameMessage(text){$('#gameMessage').textContent=text;}
function updateBet(){ const input=$('#betValue'); if(input) input.value=String(state.bet); else $('#betValue').textContent=fmt(state.bet); }
async function openGame(){setView('game');}
async function spin(){if(state.spinning||!state.user)return;if(state.user.chips<state.bet){setGameMessage('Chip tidak cukup — ambil bonus gratis untuk bermain.');toast('Chip tidak cukup. Klaim isi ulang gratis.');stopAuto();return;}
 state.spinning=true;$('#spinButton').disabled=true;$('#spinButton').innerHTML='<span>PUTAR…</span><small>SEDANG BERJALAN</small>';$('#gameMessage').textContent='Gulungan sedang berputar…';const cells=$$('.reel-cell');cells.forEach(c=>c.classList.add('spinning'));
 try{const result=await api('/api/game/spin',{method:'POST',body:{bet:state.bet}});await new Promise(resolve=>setTimeout(resolve,850));renderGrid(result.grid,result.wins.map(w=>w.row));setUser(result.user);state.round++;$('#roundLabel').textContent=`ROUND ${String(state.round).padStart(5,'0')}`;const total=result.payout;
  if(total>0){const desc=result.wins.map(w=>`${symbolNames[w.symbol]} ×${w.count}`).join(' • ');setGameMessage(`MENANG ${fmt(total)} CHIP  —  ${desc}`);$('#winFlash').classList.remove('active');void $('#winFlash').offsetWidth;$('#winFlash').classList.add('active');}else{setGameMessage(`Belum menang. Taruhan ${fmt(result.bet)} chip telah digunakan.`);}
 }catch(err){setGameMessage(err.message);toast(err.message);if(err.message.includes('Sesi berakhir'))stopAuto();}
 finally{state.spinning=false;$('#spinButton').disabled=false;$('#spinButton').innerHTML='<span>SPIN</span><small>PUTAR SEKARANG</small>';$('#reels').querySelectorAll('.reel-cell').forEach(c=>c.classList.remove('spinning'));refreshUser().catch(()=>{});if(state.auto){state.autoTimer=setTimeout(()=>spin(),1100);}}
}
function stopAuto(){state.auto=false;clearTimeout(state.autoTimer);$('#autoSpin').textContent='▶ AUTO: OFF';}
async function bonus(which){try{const d=await api(which==='daily'?'/api/chips/daily':'/api/chips/refill',{method:'POST',body:{}});setUser(d.user);await refreshUser();toast(d.message);if(which==='daily')$('#claimHint').textContent='Bonus harian berhasil diklaim';}catch(err){toast(err.message);}}
async function loadRank(){const d=await api('/api/leaderboard');const root=$('#rankTable');root.innerHTML='';if(!d.players.length){root.innerHTML='<div class="table-row"><span>—</span><span>Belum ada pemain</span><span>0</span><span>0</span></div>';return;}d.players.forEach(p=>{const row=document.createElement('div');row.className='table-row';const rank=document.createElement('b');rank.textContent=`#${p.rank}`;const name=document.createElement('span');name.textContent=p.username;const spins=document.createElement('span');spins.textContent=fmt(p.spins);const wins=document.createElement('b');wins.textContent=fmt(p.wins);row.append(rank,name,spins,wins);root.append(row);});}
async function loadMiniRank(){try{const d=await api('/api/leaderboard');const root=$('#miniRank');root.innerHTML='';if(!d.players.length){root.innerHTML='<p class="empty-line">Belum ada peringkat. Mulai permainan pertama!</p>';return;}d.players.slice(0,3).forEach(p=>{const row=document.createElement('div');row.className='mini-rank-row';row.innerHTML=`<span class="rank-number">${p.rank}</span>`;const name=document.createElement('span');name.className='rank-name';name.textContent=p.username;const score=document.createElement('span');score.className='rank-score';score.textContent=`${fmt(p.wins)} kemenangan`;row.append(name,score);root.append(row);});}catch{}}
function openRewards(){setView('rewards');refreshUser().catch(()=>{});}

$$('[data-auth-mode]').forEach(b=>b.addEventListener('click',()=>setAuthMode(b.dataset.authMode)));
$('#authForm').addEventListener('submit',async e=>{e.preventDefault();const username=$('#authUsername').value.trim();const password=$('#authPassword').value;const route=state.mode==='login'?'/api/auth/login':'/api/auth/register';$('#authError').textContent='';$('#authSubmit').disabled=true;try{const d=await api(route,{method:'POST',body:{username,password}});state.token=d.token;localStorage.setItem('dreamrealm_token',d.token);setUser(d.user);showAuth(false);await refreshUser();setView('home');toast(d.message||'Selamat datang!');}catch(err){$('#authError').textContent=err.message;}finally{$('#authSubmit').disabled=false;}});
$$('[data-nav]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.nav)));
$$('[data-open-game="olympus"]').forEach(b=>{b.addEventListener('click',openGame);b.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openGame();}});});
$('#backHome').addEventListener('click',()=>setView('home'));$('#accountButton').addEventListener('click',()=>setView('bag'));$('#openFree').addEventListener('click',openRewards);$('#panelFree').addEventListener('click',openRewards);
['dailyClaim','profileDaily','rewardDaily'].forEach(id=>$('#'+id).addEventListener('click',()=>bonus('daily')));
['gameRefill','profileRefill','rewardRefill'].forEach(id=>$('#'+id).addEventListener('click',()=>bonus('refill')));
$('#betMinus').addEventListener('click',()=>{const step=Math.max(100,Math.floor(state.bet*0.5));state.bet=Math.max(1,state.bet-step);updateBet();});$('#betPlus').addEventListener('click',()=>{const step=Math.max(100,Math.floor(state.bet*0.5));state.bet=Math.min(state.user?.chips||MAX_CHIPS,MAX_CHIPS,state.bet+step);updateBet();});$('#betValue').addEventListener('change',()=>{const n=Number($('#betValue').value);state.bet=Number.isSafeInteger(n)&&n>0?Math.min(n,state.user?.chips||MAX_CHIPS):Math.max(1,Math.min(state.bet,state.user?.chips||MAX_CHIPS));updateBet();});$('#betValue').addEventListener('keydown',e=>{if(e.key==='Enter')$('#betValue').blur();});$('#maxBet').addEventListener('click',()=>{state.bet=state.user?.chips||1;updateBet();toast('MAX BET: seluruh saldo chip virtual');});$('#spinButton').addEventListener('click',spin);
$('#autoSpin').addEventListener('click',()=>{if(state.auto){stopAuto();return;}state.auto=true;$('#autoSpin').textContent='Ⅱ AUTO: ON';spin();});
$('#logoutButton').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST',body:{}});}catch{}logoutLocal();});
$('#authUsername').addEventListener('input',()=>$('#authError').textContent='');
async function boot(){renderInitialReels();updateBet();if(!state.token){showAuth(true);return;}try{await refreshUser();showAuth(false);setView('home');}catch{showAuth(true);}}
boot();

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
